<!-- Adrian Caleb Jaramillo Flores
Matrícula: 367857
a367857@uach.mx

Abel González Mireles
Matrícula: 361031
a361031@uach.mx

Ana Rebeca Moreno Reza
Matrícula: 367783
a367783@uach.mx

Miguel David Rodríguez Glez.
Matrícula: 343786
a343786@uach.mx -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generador de Tablas</title>
    <style>
        /* Estilos generales */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #2c3e50, #4a69bd);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
            color: #333;
        }
        
        .container {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 800px;
            padding: 30px;
            margin: 20px 0;
        }
        
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 25px;
            font-size: 32px;
            position: relative;
            padding-bottom: 15px;
        }
        
        h1::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(to right, #4a69bd, #6a89cc);
            border-radius: 2px;
        }
        
        /* Formulario */
        .form-container {
            text-align: center;
            padding: 20px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #2c3e50;
            font-size: 18px;
        }
        
        input[type="text"] {
            width: 100%;
            max-width: 300px;
            padding: 14px 20px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
            margin: 0 auto;
            display: block;
            text-align: center;
        }
        
        input[type="text"]:focus {
            border-color: #4a69bd;
            outline: none;
            box-shadow: 0 0 0 3px rgba(74, 105, 189, 0.2);
        }
        
        input[type="text"]::placeholder {
            color: #aaa;
        }
        
        .btn {
            background: linear-gradient(to right, #4a69bd, #6a89cc);
            color: white;
            border: none;
            padding: 14px 30px;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            font-weight: 600;
            margin-top: 10px;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        /* Tabla */
        .table-container {
            overflow-x: auto;
            margin: 25px 0;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        
        th, td {
            padding: 15px;
            text-align: center;
            border: 1px solid #e0e0e0;
        }
        
        th {
            background: linear-gradient(to right, #4a69bd, #6a89cc);
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        
        tr:nth-child(odd) {
            background-color: #ffffff;
        }
        
        tr:hover {
            background-color: #e9ecef;
            transition: background-color 0.2s;
        }
        
        /* Enlace de volver */
        .back-link {
            display: inline-block;
            margin-top: 25px;
            padding: 12px 25px;
            background: linear-gradient(to right, #4a69bd, #6a89cc);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .back-link:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .actions {
            text-align: center;
            margin-top: 30px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }
            
            h1 {
                font-size: 26px;
            }
            
            input[type="text"] {
                max-width: 100%;
            }
            
            th, td {
                padding: 10px;
                font-size: 14px;
            }
        }
        
        @media (max-width: 480px) {
            h1 {
                font-size: 22px;
            }
            
            label {
                font-size: 16px;
            }
            
            th, td {
                padding: 8px;
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Crear filas</h1>
        
        <div class="form-container">
            <form action="columnas_creadas.php" method="post">
                <div class="form-group">
                    <label for="numfil">Ingresa el número de filas:</label>
                    <input type="text" name="numfil" id="numfil" placeholder="Número de filas..." required>
                </div>
                
                <input type="submit" value="Crear tabla" class="btn">
            </form>
        </div>
    </div>
</body>
</html>