<?php
session_start();
    $conexion = mysqli_connect("localhost", "root", "", "usuarios");

//Si ya existían cookies
if((isset($_COOKIE['usuario']))&&(isset($_COOKIE['password']))){
    //Comparar valor de las cookies con lo que existe en la DB
            
    if(($_COOKIE["usuario"] == $usuariodb) && ($_COOKIE["password"] == $passdb)) {
    //ingreso exitoso
    header("Location: bienvenida.php");
    exit();
} else {
    header("Location: LoginCookies.php?error=4");
    exit();
}

    
}


//Autentica información del usuario
//Atrapamos los valores provenientes del formulario
$usuario = $_POST["user"];
$password = $_POST["pass"];

//      Se compara con la información de la base de datos
//En este punto es donde se hacen las querys, queda pendiente.
$query = "select * from users where usuario = '$usuario' AND password = '$password';";
$resultado_consulta = mysqli_query($conexion, $query);
$registro = mysqli_fetch_array($resultado_consulta);


//Se compara con la información de la base de datos
if(mysqli_num_rows($resultado_consulta) > 0) {
    //Ingreso exitoso
    $_SESSION["logueado"] = true;
    $_SESSION["usuario"] = $usuario;

    //ingreso exitoso
    if(isset($_POST["recordar"])) {
        setcookie("usuario",$usuario,time()+60*5);
        setcookie("password",$password, time()+60*5);
    }

    header("Location: bienvenida.php");
    exit();

} else {
    header("Location: LoginCookies.php?error=1");
    exit();
}

?>