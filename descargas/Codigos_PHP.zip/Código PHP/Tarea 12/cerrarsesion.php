<?php
    //Esta página solo cierra la sesión y redirecciona al formulario inicial.
    session_start();

    //Se procede a destruir la sesión, así bien maquiavélico
    session_destroy();
    $_SESSION = [];

    //Se destruyen las cookies
    setcookie("usuario","",time()-1000000000);
    setcookie("password","", time()-1000000000);

    //Se redirige, finalmente al formulario inicial
    header("LOCATION:LoginCookies.php");
    exit();
?>