<?php
  //Verifica si existen las cookies
  if((isset($_COOKIE['usuario']))&&(isset($_COOKIE['password']))){
    //Sí existen las cookies
    header("Location: autentica.php");
    exit();
  }
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>o: Tarea 12 :o</title>
  <style>
    /* Estilos globales */
    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #fff;
    }

    /* Contenedor */
    .form-container {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
      text-align: center;
      width: 350px;
      transition: transform 0.3s ease;
    }

    .form-container:hover {
      transform: scale(1.05);
    }

    /* Título */
    .form-container h2 {
      margin-bottom: 20px;
      font-size: 28px;
      text-transform: uppercase;
      letter-spacing: 2px;
      background: linear-gradient(90deg, #ff00cc, #3333ff);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    /* Inputs */
    .form-container input[type="text"] {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border: none;
      border-radius: 10px;
      outline: none;
      font-size: 16px;
      background: rgba(255, 255, 255, 0.15);
      color: #fff;
      transition: all 0.3s ease;
    }

    .form-container input[type="text"]::placeholder {
      color: #ccc;
    }

    .form-container input[type="text"]:focus {
      background: rgba(255, 255, 255, 0.25);
      box-shadow: 0 0 10px #ff00cc, 0 0 20px #3333ff;
    }

    /* Botón */
    .form-container button {
      margin-top: 15px;
      width: 100%;
      padding: 12px;
      font-size: 18px;
      font-weight: bold;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      background: linear-gradient(90deg, #ff00cc, #3333ff);
      color: #fff;
      text-transform: uppercase;
      letter-spacing: 2px;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.4);
    }

    .form-container button:hover {
      background: linear-gradient(90deg, #3333ff, #ff00cc);
      box-shadow: 0 0 15px #ff00cc, 0 0 25px #3333ff;
      transform: translateY(-3px);
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Ingreso al sistema</h2>
    <form action="autentica.php" method = "POST">
        Usuario: <input type = "text" placeholder = "Usuario" name = "user"/>
        <br> Contraseña: <input type = "text" placeholder = "Contraseña" name = "pass" />
        <br> <input type = "submit" value = "Iniciar sesión"/>

    </form>   

    <div class="checkbox container">
      <input type = "checkbox" id="recordar" name="recordar">
      <label for = "recordar"> Recordar sesión</label>
      <div>
      <?php
        if (isset($_GET['error']))
          if($_GET['error'] == '1') {
          echo "usuario o contraseña incorrectos";
        }
      ?>
      </div>
    </div>
  </div>
</body>
</html>
