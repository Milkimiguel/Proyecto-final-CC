<?php
    echo $_COOKIE["usuario"];   
?>