<?php

    session_start();
    //verificar que la creaon fue creada
    if(!isset($_SESSION["logueado"])){   //se redirige a formulario inicial 
        header("Location: LoginCookies.php");
        exit();
    }
?>
<html>
    <h1>Bienvenido :D</h1>
    <?php

    
    if(isset($_SESSION["usuario"])) {
        echo "Bienvenido(a) " . $_SESSION["usuario"];
    } else {
        echo "Bienvenido(a)";
    }
    
    ?>
</html>