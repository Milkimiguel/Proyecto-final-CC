/*
Abel González Mireles - 361031
Adrián Caleb Jaramillo Flores - 367857
Ana Rebeca Moreno Reza - 367783
Miguel David Rodríguez González - 343786
*/

<?php
    if (isset($_COOKIE['colorSelect'])) {
        $color = $_COOKIE['colorSelect'];
        echo '<center><div style = "padding-top: 50vh;color: '.$color.';">Texto de color '.$color.' </div></center>';
    }
    elseif (isset($_GET['colorSelect'])) {
        $color = $_GET['colorSelect'];

        setcookie("colorSelect", $color, time()+3*60);
        
        echo '<center><div style = "padding-top: 50vh;color: '.$color.';">Texto de color '.$color.' </div></center>';
    }
    else{
        header("location: Tarea11.php");
        exit();
    }
?>