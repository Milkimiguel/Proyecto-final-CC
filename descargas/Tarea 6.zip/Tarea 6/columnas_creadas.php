<!-- Adrian Caleb Jaramillo Flores
Matrícula: 367857
a367857@uach.mx

Abel González Mireles
Matrícula: 361031
a361031@uach.mx

Ana Rebeca Moreno Reza
Matrícula: 367783
a367783@uach.mx

Miguel David Rodríguez Glez.
Matrícula: 343786
a343786@uach.mx -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla Generada</title>
    <style>
        /* Estilos generales */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #2c3e50, #4a69bd);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
            color: #333;
        }
        
        .container {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 800px;
            padding: 30px;
            margin: 20px 0;
        }
        
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 25px;
            font-size: 32px;
            position: relative;
            padding-bottom: 15px;
        }
        
        h1::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(to right, #4a69bd, #6a89cc);
            border-radius: 2px;
        }
        
        /* Tabla */
        .table-container {
            overflow-x: auto;
            margin: 25px 0;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        
        th, td {
            padding: 15px;
            text-align: center;
            border: 1px solid #e0e0e0;
        }
        
        th {
            background: linear-gradient(to right, #4a69bd, #6a89cc);
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        
        tr:nth-child(odd) {
            background-color: #ffffff;
        }
        
        tr:hover {
            background-color: #e9ecef;
            transition: background-color 0.2s;
        }
        
        /* Enlace de volver */
        .back-link {
            display: inline-block;
            margin-top: 25px;
            padding: 12px 25px;
            background: linear-gradient(to right, #4a69bd, #6a89cc);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .back-link:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .actions {
            text-align: center;
            margin-top: 30px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }
            
            h1 {
                font-size: 26px;
            }
            
            th, td {
                padding: 10px;
                font-size: 14px;
            }
        }
        
        @media (max-width: 480px) {
            h1 {
                font-size: 22px;
            }
            
            th, td {
                padding: 8px;
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Tabla generada</h1>
        
        <div class="table-container">
            <table>
                <tr>
                    <th>Columna 1</th>
                    <th>Columna 2</th>
                    <th>Columna 3</th>
                </tr>

                <?php 
                    $numeroFilas = $_POST['numfil'];
                    $numeroFilas = intval($numeroFilas);
                
                    for ($i = 1; $i<=$numeroFilas; $i++){
                        echo '<tr>';
                        for ($j = 1; $j<=3; $j++) {
                            echo '<td>Fila ' . $i . ', Columna ' . $j . '</td>';
                        }
                        echo '</tr>';
                    }
                ?>
            </table>
        </div>
        
        <div class="actions">
            <a href="columnas.php" class="back-link">Generar otra tabla</a>
        </div>
    </div>
</body>
</html>