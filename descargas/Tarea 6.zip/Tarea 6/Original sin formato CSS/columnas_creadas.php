<!-- Adrian Caleb Jaramillo Flores
Matrícula: 367857
a367857@uach.mx

Abel González Mireles
Matrícula: 361031
a361031@uach.mx

Ana Rebeca Moreno Reza
Matrícula: 367783
a367783@uach.mx

Miguel David Rodríguez Glez.
Matrícula: 343786
a343786@uach.mx -->

<!DOCTYPE html>
<html lang="es">

  <head>
  </head>

  <body>

    <h1>Tabla generada</h1>
    <div>
        <table border="1">
            <tr>
                <th>Columna 1</th>
                <th>Columna 2</th>
                <th>Columna 3</th>
            </tr>

        <?php 
            $numeroFilas = $_POST['numfil'];

            $numeroFilas = intval($numeroFilas);
        
            for ($i = 1; $i<=$numeroFilas; $i++){
                echo '<tr>';
                for ($j = 1; $j<=3; $j++) {
                    echo '<td>Fila ' . $i . ', Columna ' . $j . '</td>';
                }
                echo '</tr>';
            }
        ?>
    </div>
    <div>
        <a href="columnas.php" class="back-link">Generar otra tabla</a>
    </div>
  </body>
