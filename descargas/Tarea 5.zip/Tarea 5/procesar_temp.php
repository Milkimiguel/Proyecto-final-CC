<!-- Adrian Caleb Jaramillo Flores
Matrícula: 367857
a367857@uach.mx

Abel González Mireles
Matrícula: 361031
a361031@uach.mx

Ana Rebeca Moreno Reza
Matrícula: 367783
a367783@uach.mx

Miguel David Rodríguez Glez.
Matrícula: 343786
a343786@uach.mx -->


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado de Conversión</title>
    <style>
        /* Estilos generales */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            padding: 30px;
            text-align: center;
        }
        
        h1 {
            color: #2c3e50;
            margin-bottom: 25px;
            font-size: 28px;
            position: relative;
            padding-bottom: 15px;
        }
        
        h1::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(to right, #1a2a6c, #b21f1f, #fdbb2d);
            border-radius: 2px;
        }
        
        .result {
            margin: 25px 0;
            padding: 25px;
            background-color: #e8f4fc;
            border-radius: 10px;
            border-left: 5px solid #3498db;
        }
        
        .result p {
            font-size: 22px;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        
        .temperature-value {
            font-size: 28px;
            color: #e74c3c;
            font-weight: 700;
            display: block;
            margin: 10px 0;
        }
        
        .error {
            margin: 20px 0;
            padding: 20px;
            background-color: #ffdddd;
            border-radius: 10px;
            border-left: 5px solid #e74c3c;
        }
        
        .error p {
            color: #e74c3c;
            font-weight: 600;
            font-size: 18px;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 25px;
            background: linear-gradient(to right, #1a2a6c, #3498db);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .back-link:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }
            
            h1 {
                font-size: 24px;
            }
            
            .result p {
                font-size: 18px;
            }
            
            .temperature-value {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Resultado de la conversión</h1>
        
        <div class="result">
            <?php 
                $temp = $_GET['temperatura'];
                $trans = $_GET['conversion'];

                $temp = floatval($temp);
                
                if($trans == 'cen_to_far') {
                    $farenheit = ($temp * (9/5)) + 32;
                    echo "<p><span class='temperature-value'>" . $temp . "°C</span> equivalen a <span class='temperature-value'>" . number_format($farenheit, 1) . "°F</span></p>";
                } elseif($trans == 'far_to_cen') {
                    $centigrados = ($temp - 32) * (5/9);
                    echo "<p><span class='temperature-value'>" . $temp . "°F</span> equivalen a <span class='temperature-value'>" . number_format($centigrados, 1) . "°C</span></p>";
                } else {
                    echo "<div class='error'><p>Hubo un error. Por favor, selecciona una opción de conversión válida.</p></div>";
                }
            ?>
        </div>
        
        <a href="temperatura.php" class="back-link">Realizar otra conversión</a>
    </div>
</body>
</html>