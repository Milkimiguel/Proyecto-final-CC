<!-- Adrian Caleb Jaramillo Flores
Matrícula: 367857
a367857@uach.mx

Abel González Mireles
Matrícula: 361031
a361031@uach.mx

Ana Rebeca Moreno Reza
Matrícula: 367783
a367783@uach.mx

Miguel David Rodríguez Glez.
Matrícula: 343786
a343786@uach.mx  -->


<!DOCTYPE html>
<html lang="es">
<head>
    <title>Resultado</title>
</head>
<body>
    <h1>Resultado de la conversión</h1>
        <?php 
            $temp = $_GET['temperatura'];
            $trans = $_GET['conversion'];

            $temp = floatval($temp);
            
            if($trans == 'cen_to_far') {
                $farenheit = ($temp * (9/5)) + 32;
                // header("Location:./temperatura.php?temp=$farenheit");
                echo "<p>" . $temp . "°C son " . $farenheit . "°F </p>";
            } elseif($trans == 'far_to_cen') {
                $centigrados = ($temp - 32) * (5/9);
                // header("Location:./temperatura.php?temp=$centigrados");
                echo "<p>" . $temp . "°F son " . $centigrados . "°C </p>";
            } else {
                // Redireccionamiento a formulario con mensaje de error
                echo "<p> Hubo un error </p>";
            }
            exit();

?>
</body>
</html>