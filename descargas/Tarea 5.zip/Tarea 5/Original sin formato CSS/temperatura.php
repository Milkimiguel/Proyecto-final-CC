<!-- Adrian Caleb Jaramillo Flores
Matrícula: 367857
a367857@uach.mx

Abel González Mireles
Matrícula: 361031
a361031@uach.mx

Ana Rebeca Moreno Reza
Matrícula: 367783
a367783@uach.mx

Miguel David Rodríguez Glez.
Matrícula: 343786
a343786@uach.mx -->

<!DOCTYPE html>
<html lang="es">

  <head>
  </head>

  <body>

    <h1>Transformar temperaturas</h1>

    <form action="procesar_temp.php" method="get">
      <p>Introduce la temperatura</p>
      <input type="text" name="temperatura"> 
      <br>
      <input type="radio" name="conversion" id="cen_to_far" value="cen_to_far">
      <label for="cen_to_far">Centígrados a Farenheit</label>
      <br>
      <input type="radio" name="conversion" id="far_to_cen" value="far_to_cen">
      <label for="far_to_cen">Farenheit a Centígrados</label>
      <br>
      <input type="submit" name="transformar" value="Transformar">
    </form>

  </body>

</html>