<!-- Adrian Caleb Jaramillo Flores
Matrícula: 367857
a367857@uach.mx

Abel González Mireles
Matrícula: 361031
a361031@uach.mx

Ana Rebeca Moreno Reza
Matrícula: 367783
a367783@uach.mx

Miguel David Rodríguez Glez.
Matrícula: 343786
a343786@uach.mx -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Convertidor de Temperaturas</title>
    <style>
        /* Estilos generales */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 500px;
            padding: 30px;
            text-align: center;
        }
        
        h1 {
            color: #2c3e50;
            margin-bottom: 25px;
            font-size: 28px;
            position: relative;
            padding-bottom: 15px;
        }
        
        h1::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(to right, #1a2a6c, #b21f1f, #fdbb2d);
            border-radius: 2px;
        }
        
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        input[type="text"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        input[type="text"]:focus {
            border-color: #3498db;
            outline: none;
        }
        
        .radio-group {
            margin: 20px 0;
            text-align: left;
        }
        
        .radio-option {
            display: flex;
            align-items: center;
            margin-bottom: 12px;
            padding: 12px 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
            transition: background-color 0.3s;
            cursor: pointer;
        }
        
        .radio-option:hover {
            background-color: #e9ecef;
        }
        
        input[type="radio"] {
            margin-right: 10px;
            accent-color: #3498db;
        }
        
        .btn {
            background: linear-gradient(to right, #1a2a6c, #3498db);
            color: white;
            border: none;
            padding: 14px 25px;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            font-weight: 600;
            margin-top: 10px;
            width: 100%;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .result {
            margin-top: 25px;
            padding: 20px;
            background-color: #e8f4fc;
            border-radius: 8px;
            border-left: 5px solid #3498db;
        }
        
        .result h2 {
            color: #2c3e50;
            margin-bottom: 15px;
        }
        
        .result p {
            font-size: 20px;
            color: #2c3e50;
            font-weight: 600;
        }
        
        .temperature-value {
            font-size: 24px;
            color: #e74c3c;
            font-weight: 700;
        }
        
        .error {
            margin-top: 20px;
            padding: 15px;
            background-color: #ffdddd;
            border-radius: 8px;
            border-left: 5px solid #e74c3c;
            color: #e74c3c;
            font-weight: 600;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #3498db;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }
        
        .back-link:hover {
            color: #1a2a6c;
            text-decoration: underline;
        }
        
        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }
            
            h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Transformar temperaturas</h1>
        
        <form action="procesar_temp.php" method="get">
            <div class="form-group">
                <label for="temperatura">Introduce la temperatura</label>
                <input type="text" name="temperatura" id="temperatura" placeholder="Ej: 25, 32, 100..." required>
            </div>
            
            <div class="radio-group">
                <div class="radio-option">
                    <input type="radio" name="conversion" id="cen_to_far" value="cen_to_far" required>
                    <label for="cen_to_far">Centígrados a Fahrenheit</label>
                </div>
                
                <div class="radio-option">
                    <input type="radio" name="conversion" id="far_to_cen" value="far_to_cen">
                    <label for="far_to_cen">Fahrenheit a Centígrados</label>
                </div>
            </div>
            
            <button type="submit" class="btn">Transformar Temperatura</button>
        </form>
    </div>
</body>
</html>