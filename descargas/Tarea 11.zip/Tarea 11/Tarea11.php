/*
Abel González Mireles - 361031
Adrián Caleb Jaramillo Flores - 367857
Ana Rebeca Moreno Reza - 367783
Miguel David Rodríguez González - 343786
*/

<?php
  if (isset($_COOKIE['colorSelect'])) {
    header("location: resultado.php");
    exit();
  }
?>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Seleccionar Color</title>
<style>
  body {
    background: linear-gradient(135deg, #f0f4f8, #d9e4f5);
    font-family: "Segoe UI", sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }

  .form-container {
    background: white;
    padding: 30px 40px;
    border-radius: 20px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    text-align: center;
  }

  h2 {
    color: #333;
    margin-bottom: 20px;
  }

  select {
    width: 100%;
    padding: 10px;
    font-size: 1em;
    border-radius: 10px;
    border: 1px solid #ccc;
    outline: none;
    margin-bottom: 20px;
    transition: border 0.3s;
  }

  select:focus {
    border-color: #4A90E2;
  }

  button {
    background-color: #4A90E2;
    color: white;
    border: none;
    padding: 10px 25px;
    border-radius: 10px;
    cursor: pointer;
    font-size: 1em;
    transition: background-color 0.3s;
  }

  button:hover {
    background-color: #357ABD;
  }
</style>
</head>
  <body>

    <div class="form-container">
      <h2>Selecciona un color</h2>
      <form id="colorForm" action="resultado.php" method="get">
        <select id="colorSelect" name="colorSelect" required>
          <option value="" disabled selected>-- Elige un color --</option>
          <option value="red">Rojo</option>
          <option value="blue">Azul</option>
          <option value="green">Verde</option>
          <option value="yellow">Amarillo</option>
        </select>
        <button type="submit">Elegir</button>
      </form>
    </div>

  </body>
</html>
